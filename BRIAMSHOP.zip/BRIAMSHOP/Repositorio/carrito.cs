﻿using BRIAMSHOP.Models;
using System.Text.Json;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace BRIAMSHOP.Repositorio
{
	public interface IRepositoriocarrito
	{
		void actualizarItemcarro(int productId, int cantidad);
		void agregar(carritoModel productoId, int cantidad);
		void eliminarItemcarro(int productId);
		List<carroitem> ListarItemscarro();
	}

	public class Repositoriocarrrito : IRepositoriocarrito
	{
		private readonly productoSeleccionados _productoSeleccionados;
		private readonly IHttpContextAccessor _httpContextAccessor;
		private readonly string cnx;
		public Repositoriocarrrito(productoSeleccionados _productoseleccionados, IHttpContextAccessor httpContextAccessor,IConfiguration configuration)
		{
			_httpContextAccessor = httpContextAccessor;
			_productoSeleccionados = _productoseleccionados;
			cnx = configuration.GetConnectionString("DefaultConnection");
		}

		private productoSeleccionados obtenerItemsSesion()
		{
			var session = _httpContextAccessor.HttpContext.Session;
			var cartJson = session.GetString("Carrito");
			return string.IsNullOrEmpty(cartJson)
				? new productoSeleccionados()
				: JsonSerializer.Deserialize<productoSeleccionados>(cartJson);
		}

		private void guardarItemsSesion(productoSeleccionados cart)
		{
			var session = _httpContextAccessor.HttpContext.Session;
			session.SetString("Carrito", JsonSerializer.Serialize(cart));
		}

		public void agregar (carritoModel productoId, int cantidad)
		{
			var cart = obtenerItemsSesion();
			var existingItem = cart.items.FirstOrDefault(i => i.Producto.codigo == productoId.codigo);
			if (existingItem != null)
			{
				existingItem.cantidad += cantidad;
			}

			else
			{
				cart.items.Add(new carroitem { Producto = productoId, cantidad = cantidad });
			}

			guardarItemsSesion(cart);
		}

		public void eliminarItemcarro(int productId)
		{
			var cart = obtenerItemsSesion();
			var item = cart.items.FirstOrDefault(i => i.Producto.codigo == productId);

			if (item != null)
			{
				cart.items.Remove(item);
				guardarItemsSesion(cart);
			}
		}

		public decimal obtenerTotal()
		{
			return _productoSeleccionados.Totalprecio;
		}

		public void actualizarItemcarro(int productId, int cantidad)
		{
			var cart = obtenerItemsSesion();
			var existeItem = cart.items.FirstOrDefault(i => i.Producto.codigo == productId);

			if (existeItem != null)
			{
				existeItem.cantidad = cantidad;
			}

			guardarItemsSesion(cart);
		}

		public List<carroitem> ListarItemscarro()
		{
			return obtenerItemsSesion().items;
		}


	}
}
