﻿using BRIAMSHOP.Models;
using Dapper;
using System.Data.SqlClient;

namespace BRIAMSHOP.Repositorio
{
    public interface IRepositoriocontactanos
    {
        Task<bool> infocontactoModel(infocontactoModel contacto);
    }
    public class Repositoriocontactanos : IRepositoriocontactanos
    {
        private readonly string cnx;

        public Repositoriocontactanos(IConfiguration configuration)
        {
            cnx = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<bool> infocontactoModel(infocontactoModel contacto)
        {
            bool IsInserted = false;
            try
            {
                var connection = new SqlConnection(cnx);
                IsInserted = await connection.ExecuteAsync
                    (
                      @"INSERT INTO contactanos (nombre,correo,mensaje) VALUES(@nombre,@correo,@mensaje)", contacto) > 0;
            }
            catch
            (Exception ex)
            {
                string msg = ex.Message;
            }
            return IsInserted;
        }
    }
}
