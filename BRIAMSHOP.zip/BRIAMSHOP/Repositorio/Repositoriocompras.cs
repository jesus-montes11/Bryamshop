﻿using BRIAMSHOP.Models;
using Dapper;
using System.Data.SqlClient;

namespace BRIAMSHOP.Repositorio
{
	public interface IRepositoriocompras
	{
		Task BorrarProductos(int id);
		Task<insertarproductomodel> obtenercompra(string codigo);
	}
	public class Repositoriocompras:IRepositoriocompras
	{
		private readonly string cnx;

		public Repositoriocompras(IConfiguration configuration)
		{
			cnx = configuration.GetConnectionString("DefaultConnection");
		} 
		public async Task BorrarProductos(int id)
		{
			using var connection=new SqlConnection(cnx);
			var query = "DELETE FROM productos WHERE codigo=@codigo";
			await connection.ExecuteAsync(query, new {codigo=id});
		}
		public async Task<insertarproductomodel>obtenercompra(string codigo)
		{
			try
			{
				using var connection = new SqlConnection(cnx);
				var query = "SELECT codigo,nombre,preciov,unidades FROM productos WHERE codigo=@codigo";
				return await connection.QueryFirstOrDefaultAsync<insertarproductomodel>(query, new { codigo = codigo });
			}
			catch (Exception ex)
			{
				string msg = ex.Message;
			}
			return null;
		}
	}
}
