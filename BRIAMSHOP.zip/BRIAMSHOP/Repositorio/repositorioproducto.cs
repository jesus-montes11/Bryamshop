﻿using BRIAMSHOP.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.Data.SqlClient;

namespace BRIAMSHOP.Repositorio
{
    public interface Irepositorioproducto
    {
        carritoModel agregar(int productoId, int cantidad);
        insertarproductomodel infoproducto(int idproducto);

        List<insertarproductomodel> HacerPDF2(insertarproductomodel hacer1);
        Task<bool> insertarproductomodel(insertarproductomodel productos);
        Task<insertarproductomodel> ObtenerProductoPorCodigo(string codigo);
    }
    public class repositorioproducto : Irepositorioproducto
    {
        private readonly string cnx;
        private readonly IConfiguration _configuration;
        public repositorioproducto(IConfiguration configuration)
        {
            cnx = configuration.GetConnectionString("DefaultConnection");
            
        }
        public async Task<bool> insertarproductomodel(insertarproductomodel productos)
        {
            bool IsInserted = false;
            try
            {
                var connetion = new SqlConnection(cnx);
                IsInserted = await connetion.ExecuteAsync
                    (
                    @"INSERT INTO productos(codigo,nombre,descripcion,preciov,unidades,estado,urlimagen,marca,modelo,color)
                      VALUES(@codigo,@nombre,@descripcion,@preciov,@unidades,@estado,@urlimagen,@marca,@modelo,@color)", productos
                    ) > 0;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return IsInserted;
        }
        public insertarproductomodel infoproducto(int codigo)
        {
            using (IDbConnection db = new SqlConnection(cnx))
            {
                string sqlQuery = "SELECT * FROM productos WHERE codigo = @codigo";
                insertarproductomodel producto = db.QuerySingleOrDefault<insertarproductomodel>(sqlQuery, new { codigo });
                return producto;

            }
        }
        public carritoModel agregar(int productoId, int cantidad)
        {
            using (IDbConnection db = new SqlConnection(cnx))
            {
                string sqlQuery = "SELECT * FROM productos WHERE codigo = @productoId";
                carritoModel productos = db.QuerySingleOrDefault<carritoModel>(sqlQuery, new { productoId, cantidad });
                return productos;

            }
        }
        public async Task<insertarproductomodel> ObtenerProductoPorCodigo(string codigo)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);
            var query = "SELECT codigo, nombre, unidades, preciov FROM productos WHERE codigo = @codigo";
            return await connection.QueryFirstOrDefaultAsync<insertarproductomodel>(query, new { codigo = codigo });
        }

        public List<insertarproductomodel> HacerPDF2(insertarproductomodel hacer1)
        {

            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(cnx);
            var query = "SELECT * FROM productos";
            using var hacer = new SqlConnection(connectionString);
            var pr = connection.Query<insertarproductomodel>(query).ToList();




            return pr;


        }



    }
}
