﻿using BRIAMSHOP.Models;
using System.Data.SqlClient;
using Dapper;

namespace BRIAMSHOP.Repositorio
{


    public interface IRepositoriopersonas
    {
        List<Registromodel> HacerPDF1(Registromodel hacer1);
    }
    public class Repositoriopersonas : IRepositoriopersonas
    {

        private readonly string cnx;
        private readonly IConfiguration configuration;
        public Repositoriopersonas(IConfiguration configuration)
        {

            cnx = configuration.GetConnectionString("DefaultConnection");
        }
        public List<Registromodel> HacerPDF1(Registromodel hacer1)
        {

            string connectionString = configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(cnx);
            var query = "SELECT * FROM tregistro";
            using var hacer = new SqlConnection(connectionString);
            var pr = connection.Query<Registromodel>(query).ToList();




            return pr;


        }
    }

}




