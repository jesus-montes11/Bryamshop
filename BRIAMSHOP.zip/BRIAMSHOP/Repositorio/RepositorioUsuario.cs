﻿using Dapper;
using BRIAMSHOP.Models;
using Microsoft.Data.SqlClient;



    public interface IRepositorioUsuario
    {
        Task<bool> Registromodel(Registromodel usuario);
        Task<bool> ValidarUsuario(iniciarsesionmodel login);
    }
    public class RepositorioUsuario : IRepositorioUsuario
    {
        private readonly string cnx;
        public RepositorioUsuario(IConfiguration configuration)
        {
            cnx = configuration.GetConnectionString("DefaultConnection");
        }
    public async Task<bool> Registromodel(Registromodel usuario)
    {
        bool isInserted = false;


        try
        {
            var connection = new SqlConnection(cnx);
            isInserted = await connection.ExecuteAsync
                (
                @"INSERT INTO tregistro (Id, firstName, rapellidos, rfecha, rsexo, rcorreo, rcontrasena) 
                  VALUES (@Id, @firstName, @rapellidos,@rfecha,@rsexo, @rcorreo, @rcontrasena)", usuario) >
                  0;

        }
        catch (Exception ex)
        {
            string msg = ex.Message;
        }
        return isInserted;
    }


            public async Task<bool> ValidarUsuario(iniciarsesionmodel login)
            {
                using var connection = new SqlConnection(cnx);
                string query = @"SELECT COUNT(1) FROM tregistro WHERE Identificacion=@firstName AND Contraseña=@rcontrasena";
                bool usuarioExiste = await connection.ExecuteScalarAsync<int>(query, new{login.firstName,login.rcontrasena}) > 0;

				return usuarioExiste;
            }
    }

    
   


