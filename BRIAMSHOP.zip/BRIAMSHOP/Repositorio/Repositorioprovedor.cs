﻿using BRIAMSHOP.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;

namespace BRIAMSHOP.Repositorio
{
    public interface IRepositorioprovedor
    {
        Task<bool> provedorModel(provedorModel provedor);
        List<provedorModel> HacerPDF3(provedorModel hacer1);
    }

    public class Repositorioprovedor : IRepositorioprovedor
    {
        private readonly string cnx;
        private readonly IConfiguration _configuration;
        public Repositorioprovedor(IConfiguration configuration)
        {
            cnx = configuration.GetConnectionString("Defaultconnection");
        }
        public async Task<bool>provedorModel(provedorModel provedor)
        {
            bool IsInserted=false;
            try
            {
                var connection = new SqlConnection(cnx);
                IsInserted = await connection.ExecuteAsync
                    (@"INSERT INTO provedores( Cedula, Nombre, Apellido, Ntelefono, Correo, Empresa) 
                                              VALUES(@Cedula, @Nombre, @Apellido, @Ntelefono, @Correo, @Empresa)", provedor) > 0;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
            return IsInserted;
        }
        public List<provedorModel> HacerPDF3(provedorModel hacer1)
        {

            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(cnx);
            var query = "SELECT * FROM provedores";
            using var hacer = new SqlConnection(connectionString);
            var pr = connection.Query<provedorModel>(query).ToList();




            return pr;


        }
    }
}

