﻿using BRIAMSHOP.Models;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace BRIAMSHOP.Repositorio
{
    public interface IRepositorioHome
    {
        IEnumerable<insertarproductomodel> listarProductos();
    }
    public class RepositorioHome : IRepositorioHome
    {
        private readonly string cnx;
        public RepositorioHome(IConfiguration configuration)
        {
            cnx = configuration.GetConnectionString("DefaultConnection");
        }
        public IEnumerable<insertarproductomodel>listarProductos()
        {
            using(IDbConnection db = new SqlConnection(cnx))
            {
                string sqlQuery = "SELECT*FROM productos";
                var producto =db.Query<insertarproductomodel>(sqlQuery).ToList();
                return producto;
            }
        }
    }
}
