﻿using BRIAMSHOP.Models;
using Dapper;
using System.Data.SqlClient;

namespace BRIAMSHOP.Repositorio
{
	public interface IRepositoriorecuperarcontraseña
	{
		Task<bool> nuevacontra(Registromodel nuevo);
	}
	public class Repositoriorecuperarcontraseña : IRepositoriorecuperarcontraseña
	{
		private readonly string cnx;
		public Repositoriorecuperarcontraseña(IConfiguration configuration)
		{
			cnx = configuration.GetConnectionString("DefaultConnetion");
		}
		public async Task<bool> nuevacontra(Registromodel nuevo)
		{
			bool IsInserted = false;
			try
			{
				var connection = new SqlConnection(cnx);
				IsInserted = await connection.ExecuteAsync
					(@"(UPDATE tregistro SET contrasena=@contrasena WHERE nombre=@nombre)", nuevo) > 0;
			}
			catch
			(Exception ex)

			{
				string msg = ex.Message;
			}
			return IsInserted;
		}
	}
}
