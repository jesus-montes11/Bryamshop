﻿namespace BRIAMSHOP.Models;
    

    public class Registromodel
    {




        public string Id { get; set; }


        public string firstName { get; set; }


        public string rapellidos { get; set; }



        public string rfecha { get; set; }

        public string rsexo { get; set; }



        public string rcorreo { get; set; }



        public string rcontrasena { get; set; }
    }



