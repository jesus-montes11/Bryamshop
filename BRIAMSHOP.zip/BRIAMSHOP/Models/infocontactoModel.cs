﻿namespace BRIAMSHOP.Models
{
    public class infocontactoModel
    {
        public string nombre { get; set; }
        public string correo { get; set; }
        public string mensaje { get; set; }
    }
}
