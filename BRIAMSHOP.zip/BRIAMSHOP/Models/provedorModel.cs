﻿namespace BRIAMSHOP.Models
{
    public class provedorModel
    {
        public string Cedula { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Ntelefono { get; set; }
        public string Correo { get; set; }
        public string Empresa { get; set; }
       
    }
}
