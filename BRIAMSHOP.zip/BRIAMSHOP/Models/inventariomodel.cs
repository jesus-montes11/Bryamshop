﻿namespace BRIAMSHOP.Models
{
    public class inventariomodel
    {
        public string nombre {  get; set; }
        public string descripcion { get; set; }
        public string comprar { get; set; }
    }
}
