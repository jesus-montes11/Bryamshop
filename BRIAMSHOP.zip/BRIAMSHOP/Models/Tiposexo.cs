﻿namespace BRIAMSHOP.Models
{
    public class Tiposexo

    {
        


    }

    
}
