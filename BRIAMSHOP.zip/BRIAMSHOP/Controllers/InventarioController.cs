﻿using Microsoft.AspNetCore.Mvc;

namespace BRIAMSHOP.Controllers
{
    public class InventarioController : Controller
    {
     //   private readonly IRepositorioHome repohome;
       // public HomeController(IRepositorioHome repositorioHome)
      //  {
      //      this.repohome = repositorioHome;
     //   }
      //  public IActionResult carrusel()
      //  {
       //     IEnumerable<InventarioViewModel> productos = repohome.ListarProductos();
       //     return View(productos);
      //  }
    }
}
